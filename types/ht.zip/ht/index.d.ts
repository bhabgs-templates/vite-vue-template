interface Window {
  g: any;
  htconfig: any;
}
